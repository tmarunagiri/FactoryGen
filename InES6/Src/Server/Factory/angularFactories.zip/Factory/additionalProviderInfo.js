<html ng-app="factorygen">
<head >
    <title>
        Angular Factory
    </title>
    <link rel="stylesheet" href="../node_modules/bootstrap/dist/css/bootstrap.css" >
    <link rel="stylesheet" href="../node_modules/bootstrap/dist/css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="../Client/css/style.css">
    <link rel="stylesheet" href="../node_modules/jstree/dist/themes/default/style.min.css">
    <base href="/">
</head>
    <body>
    
       <div ng-view></div>

        <script src="../node_modules/jquery/dist/jquery.min.js"></script>
        <script src="../node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
        <script src="../node_modules/angular/angular.min.js"></script>
        <script src="../node_modules/angular-route/angular-route.min.js"></script>
        <script src="../node_modules/jstree/dist/jstree.min.js"></script>
        <script src="/Client/common/modelfactory.js"></script>
        <script src="/Client/common/treenode.js"></script>
        <script src="/Client/app.js"></script>
        <script src="/Client/controllers/factoryController.js"></script>
    </body>
</html>